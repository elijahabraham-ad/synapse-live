# Brain structure: the folder taxonomy

Numbered top-level folders keep the brain ordered for both AI and humans. Adapt names, keep the pattern.

```
00-meta/         the system itself: mission, conventions, session logs, memory, cron docs
01-ventures/     one folder per business/product (or 01-clients/ for an agency)
02-personal/     personal context that affects business decisions
03-people/       one profile per person (family / partners / clients / advisors / network / vendors)
04-knowledge/    skills, SOPs, frameworks, brand voice
05-legal/        contracts, agreements, disputes
06-content/      blog drafts, scripts, social planners
99-inbox/        unsorted captures, triage later
_shared/         cross-cutting quick references (tech stack, contact quickref)
```

## The three-file pattern (per venture/client)

- `_brief.md`: THE living doc. Current state, single source of truth. Update inline, never duplicate.
- `decisions/YYYY-MM-DD_slug.md`: point-in-time pivots. Never edited after the fact.
- `sessions/YYYY-MM-DD_slug.md`: append-only work history.

## Conventions that keep it healthy

- Underscore-prefixed files (`_brief.md`, `_index.md`) sort first: they're each folder's front door.
- Time-series files: `YYYY-MM-DD_slug.md`.
- Frontmatter on every file: `title`, `tags`, `status`, `last_updated`. Bump `last_updated` on every edit.
- All cross-references are relative paths, so links survive a clone.
- People are profiled ONCE in 03-people/. Everything else links to the profile; nothing duplicates a bio. (Duplicated facts are where contradictions breed.)
- The index layer rots first: whenever a status changes, same-day touch (1) the brief/profile, (2) any index/matrix listing it, (3) any SOP that names it.
