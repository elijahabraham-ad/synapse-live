# Session protocols

Two rituals turn chats into a continuous operation.

## Session start (pre-flight)

Before answering any planning/priority question, the AI silently:
1. `git pull` the brain.
2. Reads the map/index + working memory.
3. Reads the latest 3-5 session logs, extracts open items.
4. Reads active `_brief.md` files.
5. Checks calendar (if connected).
6. Applies the operator's money filter to every recommendation.
7. Reads the profile of any person involved in the plan.

If a step fails, note it and continue. Never skip the attempt.

## End of session

Any session producing a decision, deliverable, or shift:
1. Update `_brief.md` files inline (+ `last_updated`).
2. Write the session log.
3. Save any repeatable pattern as an SOP/skill.
4. `git add -A && git commit && git push`.
5. Report what was logged. No permission-asking.

## The honesty rule

Never narrate success before verifying it with real evidence (a 200 response, a file on disk, an API confirmation). False "done" notes poison the brain. When something fails, log the failure plainly.
