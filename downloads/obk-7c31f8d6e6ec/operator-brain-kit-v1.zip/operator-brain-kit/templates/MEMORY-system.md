# The memory system

Claude Code supports a persistent memory directory per project. The pattern that works:

## MEMORY.md (the index)

One line per memory: `- [Title](file.md), the hook that says when it's relevant`. This index loads into context every session, so keep lines dense and useful. Never put full memory content in the index.

## One fact per file

```markdown
---
name: short-kebab-slug
description: one-line summary used for recall decisions
metadata:
  type: user | feedback | project | reference
---

The fact itself. For feedback: include WHY and HOW TO APPLY.
Link related memories with [[their-slug]].
```

- `user`: who the operator is (role, preferences).
- `feedback`: corrections the operator gave, with the why. These are gold; capture every one.
- `project`: in-flight state that must survive a chat clear. Convert relative dates to absolute.
- `reference`: pointers to external resources.

## Rules that keep memory trustworthy

- Before saving, check for an existing memory covering it: update, don't duplicate.
- Delete memories that turn out wrong. A false memory poisons every future session.
- Never claim something is "done/verified" in memory before real evidence exists.
- Don't store what the repo already records (git history, code structure); memory is for what the files can't derive.
