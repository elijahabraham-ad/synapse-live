# The skills system

A skill is captured know-how: a repeatable pattern, technique, or hard-won lesson, written so the AI (or a person) can execute it cold next time. The skills library is the compounding asset of the whole setup: the operation gets smarter every week instead of relearning.

## Capture rules

- Capture on the SECOND occurrence of anything. First time is an event, second time is a pattern.
- One skill per file in `04-knowledge/skills/`, frontmatter like everything else.
- Update existing skills inline rather than creating near-duplicates.
- Every skill records what was PROVEN (with a date), not what is hoped.
- Lessons from failures are skills too, often the best ones.

## Skill file template

```markdown
---
title: "Skill: <what it does>"
tags: [skill, <domain>]
status: active
last_updated: YYYY-MM-DD
---

# Skill: <name>

<One paragraph: when to use this, and the proof it works (date, outcome).>

## The procedure
<numbered steps, concrete enough to execute cold>

## Gotchas
<the mistakes already made so they never repeat>
```
