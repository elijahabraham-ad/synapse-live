---
title: "Skill: full-brain contradiction audit (parallel auditors)"
tags: [skill, qc, audit]
status: active
last_updated: 2026-06-11
---

# Skill: brain contradiction audit

Run quarterly or after any big strategy shift. Proven on a 600+ file brain: ~25 files of contradictions fixed in one pass.

## The shape

1. Inventory file counts per folder so the domain split is even.
2. Fan out one read-only auditor agent per domain.
3. INJECT THE CANONICAL STATE into every auditor prompt (current model, key facts, dates). Without it, auditors can't tell stale from current.
4. Scope auditors to contradictions and stale-presented-as-current ONLY. Exclude style, typos, and clearly-dated history.
5. Demand structured findings: severity, verbatim quotes of both sides, file:line for both, which is right and why.
6. Run mechanical sweeps by SCRIPT, not agent: broken links, banned strings, stale IDs.
7. Verify every high-severity finding against the actual file before editing. Agents get line numbers and sometimes facts wrong.
8. Fix unambiguous staleness immediately; surface judgment calls to the human.

## Where rot lives

Profiles, decision records, and session logs stay accurate. Rot concentrates in INDEX and APPLICATION layers: rosters, one-line venture summaries, quick-reference files, SOPs that name people. They never get touched when the underlying decision lands. The fix is a standing rule: any status change same-day touches the brief, the index, and any SOP naming it, enforced by the QC agent, not by memory.
