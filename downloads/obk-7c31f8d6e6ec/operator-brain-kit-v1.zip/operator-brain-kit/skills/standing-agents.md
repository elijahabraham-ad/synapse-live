---
title: "Skill: the two standing agents (QC pessimist + skill-logger)"
tags: [skill, qc, automation]
status: active
last_updated: 2026-06-11
---

# Skill: standing agents

Two recurring background passes turn an AI assistant into a self-correcting system. Run them as recurring jobs (in-session schedulers or cron).

## 1. The Pessimist / QC agent

On a 2-3 hour cycle: adversarially review the most recent work. Hunt for stale links, false or unverified claims, contradictions with the living docs, broken cross-references, layout breakage. Fix what is safely fixable, log the rest, surface it.

Why it earns its keep: the QC pass regularly catches the system's OWN rule violations within hours. Rules don't enforce themselves; a recurring adversarial review does. Real example: a rule about updating index files when state changes was violated by its own author within 24 hours, and the QC cycle caught it same-day.

## 2. The Skill-logger agent

On a 3-4 hour cycle: review work since the last pass. If a repeatable pattern or lesson emerged, capture it as a skill (or update an existing one inline). If nothing new, say so in one line and stop. The discipline of "one line if nothing" matters: padding kills trust in the log.
