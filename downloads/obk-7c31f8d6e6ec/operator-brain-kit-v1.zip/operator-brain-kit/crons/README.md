# Headless automation (cron + Claude Code)

The always-on layer: scheduled jobs that run `claude -p "<prompt>"` headless and commit their output to the brain. A morning briefing that's already written when you wake up, daily metrics, content drafts, QC sweeps.

## The rules that keep it safe

- Automated jobs DRAFT and REPORT only. Anything that sends, posts, spends, or deploys stays human-approved. The money guardrail holds even in automation.
- Each wrapper logs to its own file and commits its own output (best effort).
- Prompts end with output instructions: write to a dated file, no destructive changes.

## Wrapper gotchas (paid for in production)

1. **Success check = does the dated output file exist on disk.** Do NOT judge success by a dirty git tree: the headless session sometimes commits its own output, the tree reads clean, and a working job logs a false failure.
2. **Subscription session limits are real.** Heavy interactive use can drain the plan's pool and the next cron fails closed with a session-limit error. Recovery: re-run the wrapper by hand after the reset hour (make wrappers idempotent). Durable fix: a pay-as-you-go API key in the wrapper env.
3. Set `HOME` and `PATH` explicitly in wrappers; cron's environment is bare.
4. `git pull --rebase --autostash` at wrapper start so parallel jobs don't conflict.

See `wrapper-template.sh` for the proven skeleton.
