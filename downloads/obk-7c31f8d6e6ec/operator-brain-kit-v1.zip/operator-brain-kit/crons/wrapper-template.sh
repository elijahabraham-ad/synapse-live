#!/usr/bin/env bash
# Template: headless Claude cron job. Schedule with crontab, e.g.:
#   7 6 * * *  /path/to/this.sh        (daily 6:07am; avoid :00 round marks)
export HOME=/home/YOUR_USER
export PATH=$HOME/.npm-global/bin:/usr/local/bin:/usr/bin:/bin
LOG=$HOME/cron/JOB_NAME.log
DATE=$(date +%F)
BRAIN=$HOME/your-brain-repo
CLAUDE=$HOME/.npm-global/bin/claude
OUT="00-meta/reports/${DATE}_JOB_NAME.md"   # dated output file, relative to brain

cd "$BRAIN" || { echo "$(date) cd failed" >> "$LOG"; exit 1; }
mkdir -p "$(dirname "$OUT")"
echo "===== JOB_NAME $(date) =====" >> "$LOG"
git pull --rebase --autostash >> "$LOG" 2>&1 || echo "pull non-fatal" >> "$LOG"

PROMPT="<what to produce>. Write the result to ${OUT}. Draft and report only: do not send, post, spend, or change any system."
"$CLAUDE" -p "$PROMPT" --dangerously-skip-permissions >> "$LOG" 2>&1
echo "----- claude exit $? -----" >> "$LOG"

# Success = the dated file exists. Commit only if the tree is still dirty
# (the headless session may have committed it itself).
if [ -f "$OUT" ]; then
  if [ -n "$(git status --porcelain "$(dirname "$OUT")")" ]; then
    git add "$(dirname "$OUT")" >> "$LOG" 2>&1
    git commit -m "JOB_NAME ${DATE}" >> "$LOG" 2>&1
    git push >> "$LOG" 2>&1 || echo "push non-fatal" >> "$LOG"
  fi
  echo "OK: ${OUT}" >> "$LOG"
else
  echo "FAILED: no ${OUT} on disk, check log above" >> "$LOG"
fi
echo "===== JOB_NAME done $(date) =====" >> "$LOG"
