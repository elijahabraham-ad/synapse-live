# Operator Brain Kit

Turn Claude into your business's operating brain. This is the working system behind a real operator's setup: Claude Code + a local git "brain" repo + Obsidian as the viewer. No more re-explaining context every chat, no more knowledge trapped in Notion pages the AI can't act on.

Built and battle-tested daily by Eli Abraham (Adova Digital). This kit is the sanitized, reusable core: templates, conventions, and the automation patterns. Drop in your own business.

## Why local beats chat + Notion

- **Context lives on disk, not in your head.** Claude Code reads your whole brain repo every session. You stop re-explaining who you are, what you're building, and what happened last week.
- **The AI can ACT, not just answer.** Claude Code edits files, runs scripts, commits to git, automates with cron. Chat can only talk.
- **Git is your memory and your undo button.** Every change is a commit. Nothing is ever lost.
- **Obsidian is the human window.** Point it at the repo and you get a beautiful read/edit view of everything the AI maintains, with backlinks and graph view free.

## Quickstart (30 minutes)

1. Install Claude Code, log in with your Claude plan.
2. Create a private GitHub repo (your "brain"), clone it locally.
3. Copy `templates/brain-structure.md`'s folder skeleton into the repo.
4. Copy `templates/CLAUDE.template.md` to the repo root as `CLAUDE.md` and fill in YOUR business (this is the single most important file: Claude reads it at every session start).
5. Set up the memory system per `templates/MEMORY-system.md`.
6. Point Obsidian at the repo folder as a vault.
7. Open Claude Code in the repo and say "read CLAUDE.md and give me a state-of-the-business summary." If it answers like a chief of staff, you're live.
8. When ready, add the automation layer: `crons/` for daily briefings and reports, `skills/` for captured know-how.

## What's inside

| Path | What it is |
|---|---|
| `templates/CLAUDE.template.md` | The operating-brain master prompt, the file that makes Claude act like YOUR operator |
| `templates/brain-structure.md` | The folder taxonomy + file conventions that keep a brain navigable for AI and humans |
| `templates/MEMORY-system.md` | Persistent cross-session memory: index + fact files |
| `templates/session-protocols.md` | Session-start pre-flight and end-of-session backup rituals |
| `skills/` | The skills system: how the AI captures its own know-how, plus starter skills |
| `crons/` | Headless automation: daily briefings, reports, QC passes, with the hard-won gotchas |

## Roadmap

This kit evolves weekly as the live system evolves. New skills, new automation patterns, and new templates land here as they're proven in production.

## License

All rights reserved. Licensed for the use of invited collaborators; not for redistribution.
