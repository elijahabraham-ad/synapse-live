# Setup: from chat + Notion to a local operating brain

## What you're replacing

Chat + Notion = the AI answers questions but holds no durable state, and your knowledge sits where the AI can't act on it. The local setup inverts that: state lives in a git repo the AI reads AND writes, every session starts already-briefed.

## Steps

1. **Claude Code.** Install per Anthropic's docs, sign in with your plan. (On a higher-tier plan you won't feel session limits; the bigger win is context persistence.)
2. **The brain repo.** Private GitHub repo, cloned locally. Build the skeleton from `templates/brain-structure.md`.
3. **CLAUDE.md.** Copy the template to the repo root, fill in your business. Spend real time on the voice section and the standing rules; this file is 80% of the difference between a generic assistant and YOUR operator.
4. **Memory.** Set up per `templates/MEMORY-system.md`.
5. **Obsidian.** Open the repo folder as a vault. You get the human-friendly view (graph, backlinks, mobile via Obsidian Sync if wanted) while Claude works the same files.
6. **GitHub hygiene.** `.gitignore` anything secret. Credentials NEVER go in the repo; keep a gitignored local scratch file and a real password manager.
7. **First session.** "Read CLAUDE.md, then give me a state-of-the-business summary and the top 3 open items." Then start working: every meaningful session ends with the end-of-session protocol (`templates/session-protocols.md`).
8. **Automation (week 2+).** Add the cron layer from `crons/` once the brain has content worth briefing on.

## The habits that make it compound

- Capture decisions the day they happen (dated decision files).
- Let the AI write session logs; never end a real session without one.
- Feed corrections back as memory ("feedback" type) so mistakes don't repeat.
- Run the two standing agents (`skills/standing-agents.md`).
